int leerEnteroPositivo(char*);
float leerFlotantePositivo(char*);
int leerEntero(char*);
int leerEnteroEntre(int, int);
float leerFlotante(char*);
float leerFlotanteEntre(float, float);
char leerCaracter(char*);