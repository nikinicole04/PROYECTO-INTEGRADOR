/*Realice un programa que lea una temperatura a través de teclado y muestre por
pantalla la actividad más apropiada para dicha temperatura teniendo en cuenta los
siguientes criterios.
*/

#include <stdio.h>
#include "lecturas.h"
#include "operaciones.h"

int main() {
    printf("----------ACTIVIDADES DEPORTIVAS----------");
    int temperatura;
    
    printf("\nIngrese la temperatura idonea:");
    scanf("%d", &temperatura);
    
    asignarDeporte(temperatura);

    return 0;
}
