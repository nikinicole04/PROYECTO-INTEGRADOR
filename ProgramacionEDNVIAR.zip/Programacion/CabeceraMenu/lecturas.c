#include <stdio.h>
#include "lecturas.h"

int leerEnteroPositivo(char* mensaje){
    int valor;
    do{
        printf("%s", mensaje);
        scanf("%d",&valor);
    }while(valor <= 0);
    return valor;
}


float leerFlotantePositivo(char* mensaje){
    float valor;
    do{
        printf("%s", mensaje);
        scanf("%f",&valor);
    }while(valor <= 0);
    return valor;
}


int leerEntero(char* mensaje) {
    int valor;
    printf("%s", mensaje);
    scanf("%d", &valor);
    return valor;
}


int leerEnteroEntre(int min, int max) {
    int valor;
    do {
        printf("Ingrese un entero entre %d y %d: ", min, max);
        scanf("%d", &valor);
    } while (valor < min || valor > max);
    return valor;
}


float leerFlotante(char* mensaje) {
    float valor;
    printf("%s", mensaje);
    scanf("%f", &valor);
    return valor;
}


float leerFlotanteEntre(float min, float max) {
    float valor;
    do {
        printf("Ingrese un flotante entre %.2f y %.2f: ", min, max);
        scanf("%f", &valor);
    } while (valor < min || valor > max);
    return valor;
}


char leerCaracter(char* mensaje) {
    char valor;
    printf("%s", mensaje);
    scanf(" %c", &valor);
    return valor;
}