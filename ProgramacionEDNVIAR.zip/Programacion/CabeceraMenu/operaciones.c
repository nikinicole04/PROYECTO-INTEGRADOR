#include <stdio.h>
#include <math.h>
#include "operaciones.h"

void numeroPerfecto(int numero){
    int suma = 0;
    for(int i= 1; i<= numero/2;i++){
        if(numero % i == 0)
            suma+=i;
    }
   
    if(numero == suma)
        printf("el numero es perfecto");
    else
        printf("el numero no es perfecto");

}

float hipotenusa(float a,float b){
    return sqrtf(powf(a,2)+powf(b,2));
}

float tiempoPendulo(float longitud){
    return 2*3.1416* sqrtf(longitud/9.8);
}

void asignarDeporte(int temperatura) {
    if (temperatura > 30) {
        printf("Deporte asignado: Natacion");
    } else if (temperatura > 20) {
        printf("Deporte asignado: Tenis");
    } else if (temperatura > 10) {
        printf("Deporte asignado: Golf");
    } else if (temperatura > 5) {
        printf("Deporte asignado: Esqui");
    } else {
        printf("Deporte asignado: Parchis");
    }
}