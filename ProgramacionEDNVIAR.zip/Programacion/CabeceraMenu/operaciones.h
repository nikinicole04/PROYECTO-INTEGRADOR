void numeroPerfecto(int);
float hipotenusa(float,float);
float tiempoPendulo(float);
void asignarDeporte(int);